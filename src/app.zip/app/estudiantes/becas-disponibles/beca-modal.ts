import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-beca-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './beca-modal.html',
  styleUrls: ['./beca-modal.scss']
})
export class BecaModalComponent {
  @Input() beca: any = null;
  @Input() isOpen = false;

  @Output() closeModal = new EventEmitter<void>();

  closeModalHandler() {
    this.closeModal.emit();
  }
}
