import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface SolicitudFormModel {
  estudianteId: number;
  tipoBecaId: number;
  estadoId: number;
  fechaSolicitud: string;
  periodoAcademicoId: number;
  observaciones?: string | null;
  fechaResultado?: string | null;
}

@Component({
  selector: 'app-beca-solicitud-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './beca-solicitud-modal.html',
  styleUrls: ['./beca-solicitud-modal.scss']
})
export class BecaSolicitudModalComponent {
  @Input() beca: any = null;
  @Input() isOpen = false;

  @Output() closeModal = new EventEmitter<void>();
  @Output() solicitarBeca = new EventEmitter<any>();

  solicitudFormModel: SolicitudFormModel = {
    estudianteId: 0,
    tipoBecaId: 0,
    estadoId: 0,
    fechaSolicitud: new Date().toISOString().split('T')[0],
    periodoAcademicoId: 0,
    observaciones: null,
    fechaResultado: null
  };

  closeModalHandler() {
    this.closeModal.emit();
  }

  onSubmit() {
    const payload = {
      ...this.solicitudFormModel,
      observaciones: this.solicitudFormModel.observaciones || null,
      fechaResultado: this.solicitudFormModel.fechaResultado || null
    };
    this.solicitarBeca.emit({
      beca: this.beca,
      datos: payload
    });
  }
}
