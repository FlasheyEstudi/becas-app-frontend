// src/app/criterio-evaluacion/criterio-evaluacion.component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface CriterioEvaluacion {
  id: number;
  nombre: string;
  descripcion?: string;
  peso: number;
  tipoBecaId?: number;
}

interface CreateCriterioEvaluacionDto {
  nombre: string;
  descripcion?: string;
  peso: number;
  tipoBecaId?: number;
}

@Component({
  selector: 'app-criterio-evaluacion',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './criterio-evaluacion.html',
  styleUrls: ['./criterio-evaluacion.scss']
})
export class CriterioEvaluacionComponent implements OnInit {
  criterios: CriterioEvaluacion[] = [];
  filteredCriterios: CriterioEvaluacion[] = [];
  error: string = '';
  loading: boolean = false;
  newCriterio: CreateCriterioEvaluacionDto = {
    nombre: '',
    descripcion: '',
    peso: 0,
    tipoBecaId: 0
  };
  searchTerm: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.cargarCriterios();
  }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  cargarCriterios() {
    this.loading = true;
    this.error = '';
    this.http.get<CriterioEvaluacion[]>('http://localhost:3000/api-beca/CriterioEvaluacion', {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.loading = false;
        this.criterios = data;
        this.filteredCriterios = [...this.criterios];
      },
      error: (err) => {
        this.error = 'Error al cargar criterios de evaluación';
        this.loading = false;
        console.error(err);
      }
    });
  }

  onSubmitNewCriterio() {
    // Validaciones
    if (!this.newCriterio.nombre) {
      this.error = 'El nombre del criterio es requerido';
      return;
    }
    if (!this.newCriterio.peso || this.newCriterio.peso <= 0) {
      this.error = 'El peso es requerido y debe ser mayor a 0';
      return;
    }
    
    this.loading = true;
    this.error = '';
    this.http.post<CriterioEvaluacion>('http://localhost:3000/api-beca/CriterioEvaluacion/add', this.newCriterio, {
      headers: this.getHeaders()
    }).subscribe({
      next: (response) => {
        this.loading = false;
        // Resetear formulario
        this.newCriterio = {
          nombre: '',
          descripcion: '',
          peso: 0,
          tipoBecaId: 0
        };
        // Recargar lista
        this.cargarCriterios();
        alert('Criterio de evaluación creado correctamente');
      },
      error: (err) => {
        this.error = 'Error al añadir criterio de evaluación: ' + (err.error?.message || err.message);
        this.loading = false;
        console.error(err);
      }
    });
  }

  onCancel() {
    this.newCriterio = {
      nombre: '',
      descripcion: '',
      peso: 0,
      tipoBecaId: 0
    };
    this.error = '';
  }

  onSearch() {
    if (!this.searchTerm.trim()) {
      this.filteredCriterios = [...this.criterios];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredCriterios = this.criterios.filter(criterio =>
      criterio.nombre.toLowerCase().includes(term) ||
      criterio.descripcion?.toLowerCase().includes(term)
    );
  }

  deleteCriterio(id: number) {
    if (confirm('¿Estás seguro de eliminar este criterio de evaluación?')) {
      this.loading = true;
      this.http.delete(`http://localhost:3000/api-beca/CriterioEvaluacion/${id}`, {
        headers: this.getHeaders()
      }).subscribe({
        next: () => {
          this.loading = false;
          this.cargarCriterios();
          alert('Criterio de evaluación eliminado correctamente');
        },
        error: (err) => {
          this.loading = false;
          this.error = 'Error al eliminar criterio de evaluación';
          console.error(err);
        }
      });
    }
  }
}