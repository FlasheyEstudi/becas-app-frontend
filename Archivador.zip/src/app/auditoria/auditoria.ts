// src/app/auditoria/auditoria.component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Auditoria {
    id: number;
    tablaAfectada: string;
    accion: string;
    registroId: number;
    usuarioId: number;
    fecha?: string;
    detalles?: string;
}

@Component({
    selector: 'app-auditoria',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './auditoria.html',
    styleUrls: ['./auditoria.scss']
})
export class AuditoriaComponent implements OnInit {
    auditorias: Auditoria[] = [];
    filteredAuditorias: Auditoria[] = [];
    error: string = '';
    loading: boolean = false;
    searchTerm: string = '';

    constructor(private http: HttpClient, private router: Router) { }

    ngOnInit(): void {
        this.cargarAuditorias();
    }

    private getHeaders(): HttpHeaders {
        const token = localStorage.getItem('token');
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        if (token) {
            headers = headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    }

    cargarAuditorias() {
        this.loading = true;
        this.error = '';
        this.http.get<Auditoria[]>('http://localhost:3000/api-beca/Auditoria', {
            headers: this.getHeaders()
        }).subscribe({
            next: (data) => {
                this.loading = false;
                this.auditorias = data;
                this.filteredAuditorias = [...this.auditorias];
            },
            error: (err) => {
                this.error = 'Error al cargar auditorías';
                this.loading = false;
                console.error(err);
            }
        });
    }

    onSearch() {
        if (!this.searchTerm.trim()) {
            this.filteredAuditorias = [...this.auditorias];
            return;
        }
        const term = this.searchTerm.toLowerCase();
        this.filteredAuditorias = this.auditorias.filter(auditoria =>
            auditoria.tablaAfectada.toLowerCase().includes(term) ||
            auditoria.accion.toLowerCase().includes(term)
        );
    }
}