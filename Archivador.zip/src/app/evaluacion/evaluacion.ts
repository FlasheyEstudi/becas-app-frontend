// src/app/evaluacion/evaluacion.component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Evaluacion {
  id: number;
  solicitudId: number;
  evaluadorId: number;
  puntuacionTotal: number;
  comentarios?: string;
  recomendacion?: string;
  fechaEvaluacion?: string;
}

interface CreateEvaluacionDto {
  solicitudId: number;
  evaluadorId: number;
  puntuacionTotal: number;
  comentarios?: string;
  recomendacion?: string;
}

@Component({
  selector: 'app-evaluacion',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './evaluacion.html',
  styleUrls: ['./evaluacion.scss']
})
export class EvaluacionComponent implements OnInit {
  evaluaciones: Evaluacion[] = [];
  filteredEvaluaciones: Evaluacion[] = [];
  error: string = '';
  loading: boolean = false;
  newEvaluacion: CreateEvaluacionDto = {
    solicitudId: 0,
    evaluadorId: 0,
    puntuacionTotal: 0,
    recomendacion: 'pendiente'
  };
  searchTerm: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.cargarEvaluaciones();
  }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  cargarEvaluaciones() {
    this.loading = true;
    this.error = '';
    this.http.get<Evaluacion[]>('http://localhost:3000/api-beca/Evaluacion', {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.loading = false;
        this.evaluaciones = data;
        this.filteredEvaluaciones = [...this.evaluaciones];
      },
      error: (err) => {
        this.error = 'Error al cargar evaluaciones';
        this.loading = false;
        console.error(err);
      }
    });
  }

  onSubmitNewEvaluacion() {
    // Validaciones
    if (!this.newEvaluacion.solicitudId || this.newEvaluacion.solicitudId <= 0) {
      this.error = 'El ID de la solicitud es requerido y debe ser válido';
      return;
    }
    if (!this.newEvaluacion.evaluadorId || this.newEvaluacion.evaluadorId <= 0) {
      this.error = 'El ID del evaluador es requerido y debe ser válido';
      return;
    }
    if (!this.newEvaluacion.puntuacionTotal || this.newEvaluacion.puntuacionTotal < 0) {
      this.error = 'La puntuación total es requerida y debe ser mayor o igual a 0';
      return;
    }
    
    this.loading = true;
    this.error = '';
    this.http.post<Evaluacion>('http://localhost:3000/api-beca/Evaluacion/add', this.newEvaluacion, {
      headers: this.getHeaders()
    }).subscribe({
      next: (response) => {
        this.loading = false;
        // Resetear formulario
        this.newEvaluacion = {
          solicitudId: 0,
          evaluadorId: 0,
          puntuacionTotal: 0,
          recomendacion: 'pendiente'
        };
        // Recargar lista
        this.cargarEvaluaciones();
        alert('Evaluación creada correctamente');
      },
      error: (err) => {
        this.error = 'Error al añadir evaluación: ' + (err.error?.message || err.message);
        this.loading = false;
        console.error(err);
      }
    });
  }

  onCancel() {
    this.newEvaluacion = {
      solicitudId: 0,
      evaluadorId: 0,
      puntuacionTotal: 0,
      recomendacion: 'pendiente'
    };
    this.error = '';
  }

  onSearch() {
    if (!this.searchTerm.trim()) {
      this.filteredEvaluaciones = [...this.evaluaciones];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredEvaluaciones = this.evaluaciones.filter(evaluacion =>
      evaluacion.solicitudId.toString().includes(term) ||
      evaluacion.evaluadorId.toString().includes(term)
    );
  }

  deleteEvaluacion(id: number) {
    if (confirm('¿Estás seguro de eliminar esta evaluación?')) {
      this.loading = true;
      this.http.delete(`http://localhost:3000/api-beca/Evaluacion/${id}`, {
        headers: this.getHeaders()
      }).subscribe({
        next: () => {
          this.loading = false;
          this.cargarEvaluaciones();
          alert('Evaluación eliminada correctamente');
        },
        error: (err) => {
          this.loading = false;
          this.error = 'Error al eliminar evaluación';
          console.error(err);
        }
      });
    }
  }
}