// src/app/documento/documento.component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Documento {
  id: number;
  nombre: string;
  url: string;
  estudianteId: number;
}

interface CreateDocumentoDto {
  nombre: string;
  url: string;
  estudianteId: number;
}

@Component({
  selector: 'app-documento',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './documento.html',
  styleUrls: ['./documento.scss']
})
export class DocumentoComponent implements OnInit {
  documentos: Documento[] = [];
  filteredDocumentos: Documento[] = [];
  error: string = '';
  loading: boolean = false;
  newDocumento: CreateDocumentoDto = {
    nombre: '',
    url: '',
    estudianteId: 0
  };
  searchTerm: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.cargarDocumentos();
  }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  cargarDocumentos() {
    this.loading = true;
    this.error = '';
    this.http.get<Documento[]>('http://localhost:3000/api-beca/Documento', {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.loading = false;
        this.documentos = data;
        this.filteredDocumentos = [...this.documentos];
      },
      error: (err) => {
        this.error = 'Error al cargar documentos';
        this.loading = false;
        console.error(err);
      }
    });
  }

  onSubmitNewDocumento() {
    // Validaciones
    if (!this.newDocumento.nombre) {
      this.error = 'El nombre es requerido';
      return;
    }
    if (!this.newDocumento.url) {
      this.error = 'La URL es requerida';
      return;
    }
    if (!this.newDocumento.estudianteId || this.newDocumento.estudianteId <= 0) {
      this.error = 'El ID del estudiante es requerido y debe ser válido';
      return;
    }
    
    this.loading = true;
    this.error = '';
    this.http.post<Documento>('http://localhost:3000/api-beca/Documento/add', this.newDocumento, {
      headers: this.getHeaders()
    }).subscribe({
      next: (response) => {
        this.loading = false;
        // Resetear formulario
        this.newDocumento = {
          nombre: '',
          url: '',
          estudianteId: 0
        };
        // Recargar lista
        this.cargarDocumentos();
        alert('Documento creado correctamente');
      },
      error: (err) => {
        this.error = 'Error al añadir documento: ' + (err.error?.message || err.message);
        this.loading = false;
        console.error(err);
      }
    });
  }

  onCancel() {
    this.newDocumento = {
      nombre: '',
      url: '',
      estudianteId: 0
    };
    this.error = '';
  }

  onSearch() {
    if (!this.searchTerm.trim()) {
      this.filteredDocumentos = [...this.documentos];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredDocumentos = this.documentos.filter(documento =>
      documento.nombre.toLowerCase().includes(term) ||
      documento.url.toLowerCase().includes(term)
    );
  }

  deleteDocumento(id: number) {
    if (confirm('¿Estás seguro de eliminar este documento?')) {
      this.loading = true;
      this.http.delete(`http://localhost:3000/api-beca/Documento/${id}`, {
        headers: this.getHeaders()
      }).subscribe({
        next: () => {
          this.loading = false;
          this.cargarDocumentos();
          alert('Documento eliminado correctamente');
        },
        error: (err) => {
          this.loading = false;
          this.error = 'Error al eliminar documento';
          console.error(err);
        }
      });
    }
  }
}