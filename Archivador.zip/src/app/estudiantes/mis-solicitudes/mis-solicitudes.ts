import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';

interface SolicitudBeca {
  id: number;
  fechaSolicitud: string;
  estado: { nombre: string };
  tipoBeca: { nombre: string };
}

@Component({
  selector: 'app-mis-solicitudes',
  standalone: true,
  imports: [CommonModule, DatePipe],
  templateUrl: './mis-solicitudes.html',
  styleUrls: ['./mis-solicitudes.scss']
})
export class MisSolicitudesComponent implements OnInit {
  solicitudes: SolicitudBeca[] = [];
  loading = false;
  error = '';
  estudianteId: number | null = null;

  private baseUrl = 'http://localhost:3000/api-beca/solicitud-beca';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.obtenerEstudianteId();
    if (this.estudianteId) {
      this.cargarSolicitudes();
    }
  }

  private obtenerEstudianteId() {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        this.estudianteId = payload.sub || payload.id;
      } catch (err) {
        console.error('Error al decodificar token:', err);
      }
    }
  }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  cargarSolicitudes(): void {
    this.loading = true;
    this.error = '';

    this.http.get<SolicitudBeca[]>(`${this.baseUrl}/estudiante/${this.estudianteId}`, { headers: this.getHeaders() })
      .subscribe({
        next: (data) => {
          this.solicitudes = data;
          this.loading = false;
        },
        error: (err) => {
          this.error = 'Error al cargar solicitudes: ' + (err.error?.message || err.message);
          this.loading = false;
        }
      });
  }
}
